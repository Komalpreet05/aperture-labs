$(document).ready(function() {  
  $('#cookieModal').modal('show');
});